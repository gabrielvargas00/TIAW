Nos exemplos a partir do 0511, busquei escrever mais de funcao para calcular os valores pedidos. 
Entao, ao executar, alguns programas estarao mostrando a resposta mais de uma vez
(preferi fazer dessa forma a nomear arquivos diferentes, cada utilizando uma funcao)

OBS.: Todas elas estao na minha biblioteca e devidamente identificadas nos metodos
