Para o Exemplo0317 ao Exemplo0320:

Fiz algumas pesquisas para utilizar o que, aparentemente, é um vetor para incluir a leitura de mais de um numero.
Esta é realmente a maneira mais eficiente ou haveria uma outra forma?
